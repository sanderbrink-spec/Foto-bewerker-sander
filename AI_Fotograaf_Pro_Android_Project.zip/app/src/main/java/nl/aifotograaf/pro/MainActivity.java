package nl.aifotograaf.pro;

import android.app.*;
import android.os.*;
import android.provider.MediaStore;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PICK = 42;
    Button selectButton, processButton;
    ProgressBar progress;
    TextView status, result;
    ArrayList<Uri> photos = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        selectButton=findViewById(R.id.selectButton);
        processButton=findViewById(R.id.processButton);
        progress=findViewById(R.id.progress);
        status=findViewById(R.id.status);
        result=findViewById(R.id.result);

        selectButton.setOnClickListener(v -> choosePhotos());
        processButton.setOnClickListener(v -> processAll());
    }

    void choosePhotos() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK);
    }

    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d);
        if(r!=PICK || c!=RESULT_OK || d==null) return;
        photos.clear();
        if(d.getClipData()!=null) {
            int n=Math.min(100,d.getClipData().getItemCount());
            for(int x=0;x<n;x++) photos.add(d.getClipData().getItemAt(x).getUri());
        } else if(d.getData()!=null) photos.add(d.getData());
        status.setText(photos.size()+" foto"+(photos.size()==1?"":"'s")+" geselecteerd");
        processButton.setEnabled(!photos.isEmpty());
        progress.setProgress(0);
    }

    void processAll() {
        processButton.setEnabled(false);
        selectButton.setEnabled(false);
        new Thread(() -> {
            int done=0;
            for(Uri u: photos) {
                try { processOne(u); } catch(Exception ignored) {}
                done++;
                int p=(int)(done*100f/photos.size());
                runOnUiThread(() -> {
                    progress.setProgress(p);
                    status.setText("Verwerken: "+p+"%");
                });
            }
            runOnUiThread(() -> {
                selectButton.setEnabled(true);
                status.setText("Klaar • "+photos.size()+" foto's verwerkt");
                result.setText("Offline batchverwerking voltooid. Resultaten staan in de app-galerij.");
            });
        }).start();
    }

    void processOne(Uri uri) throws Exception {
        Bitmap src=BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));
        if(src==null) return;
        int max=3000;
        float scale=Math.min(1f, max/(float)Math.max(src.getWidth(),src.getHeight()));
        int w=Math.max(1,(int)(src.getWidth()*scale));
        int h=Math.max(1,(int)(src.getHeight()*scale));
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(out);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        ColorMatrix cm=new ColorMatrix(new float[]{
            1.08f,0,0,0,3, 0,1.08f,0,0,3, 0,0,1.08f,0,3, 0,0,0,1,0
        });
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(src,null,new Rect(0,0,w,h),p);

        String name="AI_"+System.currentTimeMillis()+".jpg";
        ContentValues v=new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME,name);
        v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/AI Fotograaf Pro");
        Uri dest=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
        if(dest!=null) {
            OutputStream os=getContentResolver().openOutputStream(dest);
            out.compress(Bitmap.CompressFormat.JPEG,96,os);
            os.close();
        }
        src.recycle(); out.recycle();
    }
}
